GB-5600A Link — prototyp Android (źródła)

Wymagania:
- Android Studio (aktualna wersja)
- Android 13 na telefonie
- Bluetooth włączony

Uruchomienie:
1. Rozpakuj archiwum.
2. Otwórz folder projektu w Android Studio.
3. Poczekaj na synchronizację Gradle.
4. Podłącz telefon z włączonym debugowaniem USB.
5. Uruchom aplikację przyciskiem Run.

Co robi ta wersja:
- skanuje urządzenia Bluetooth Low Energy,
- pokazuje znalezione urządzenia,
- próbuje połączyć się z wybranym urządzeniem,
- wyświetla usługi GATT udostępnione przez urządzenie.

Czego jeszcze nie robi:
- nie synchronizuje godziny,
- nie wysyła powiadomień,
- nie implementuje prywatnego protokołu Casio,
- nie gwarantuje połączenia z GB-5600A.

Ważne:
To jest prototyp diagnostyczny, a nie gotowa aplikacja zastępująca G-SHOCK+.
Dalsze funkcje można dodać dopiero po sprawdzeniu rzeczywistej komunikacji
z konkretnym egzemplarzem zegarka.

KOMPILACJA APK W CHMURZE (GITHUB ACTIONS)
1. Utwórz na GitHubie nowe repozytorium, np. GB5600A-Bluetooth-Prototype.
2. Wgraj do niego całą zawartość tego katalogu (razem z ukrytym katalogiem .github).
3. Otwórz kartę Actions w repozytorium. Przy pierwszym użyciu może być potrzebne zatwierdzenie uruchamiania workflow.
4. Workflow „Build Android APK” uruchomi się po wypchnięciu plików na gałąź main/master. Można go też uruchomić ręcznie.
5. Po zakończeniu wybierz uruchomienie workflow i pobierz artefakt „GB5600A-debug-apk”. W środku będzie app-debug.apk.

Uwaga: to debug APK prototypu diagnostycznego BLE. Samo poprawne zbudowanie APK nie potwierdza jeszcze zgodności komunikacji z zegarkiem Casio GB-5600A / modułem 3409.
