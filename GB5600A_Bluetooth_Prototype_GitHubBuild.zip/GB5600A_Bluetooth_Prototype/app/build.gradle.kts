plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "pl.example.gb5600a"
    compileSdk = 35
    defaultConfig {
        applicationId = "pl.example.gb5600a"
        minSdk = 23
        targetSdk = 33
        versionCode = 1
        versionName = "0.1"
    }
}
