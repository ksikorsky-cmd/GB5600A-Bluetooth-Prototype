package pl.example.gb5600a

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.ParcelUuid
import android.view.Gravity
import android.widget.*
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var adapter: BluetoothAdapter
    private lateinit var scanner: BluetoothLeScanner
    private lateinit var status: TextView
    private lateinit var devicesBox: LinearLayout
    private val found = linkedMapOf<String, BluetoothDevice>()
    private var gatt: BluetoothGatt? = null
    private val requestCode = 71

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        adapter = manager.adapter

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
        }
        val title = TextView(this).apply {
            text = "GB-5600A Link"
            textSize = 26f
        }
        status = TextView(this).apply {
            text = "Gotowy do wyszukiwania zegarka"
            textSize = 16f
            setPadding(0, 18, 0, 18)
        }
        val scan = Button(this).apply {
            text = "Szukaj zegarka Bluetooth"
            setOnClickListener { checkPermissionsAndScan() }
        }
        val disconnect = Button(this).apply {
            text = "Rozłącz"
            setOnClickListener {
                gatt?.disconnect()
                gatt?.close()
                gatt = null
                status.text = "Rozłączono"
            }
        }
        val note = TextView(this).apply {
            text = "Wybierz urządzenie z listy. Ta wersja testowa wykrywa BLE i odczytuje udostępnione usługi. Nie wykonuje jeszcze synchronizacji godziny ani przesyłania powiadomień."
            textSize = 13f
            setPadding(0, 16, 0, 16)
        }
        devicesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(title)
        root.addView(status)
        root.addView(scan)
        root.addView(disconnect)
        root.addView(note)
        root.addView(devicesBox)
        setContentView(ScrollView(this).apply { addView(root) })

        if (adapter == null || !packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            status.text = "Ten telefon nie udostępnia Bluetooth LE."
        } else {
            scanner = adapter.bluetoothLeScanner
        }
    }

    private fun checkPermissionsAndScan() {
        val needed = if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN,
            Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

        val missing = needed.filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), requestCode)
        } else startScan()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startScan()
        } else status.text = "Brak wymaganych uprawnień Bluetooth."
    }

    private fun startScan() {
        if (!adapter.isEnabled) {
            status.text = "Włącz Bluetooth w ustawieniach telefonu."
            return
        }
        found.clear()
        devicesBox.removeAllViews()
        status.text = "Szukam urządzeń BLE przez 12 sekund…"
        try {
            scanner.startScan(scanCallback)
            status.postDelayed({
                try { scanner.stopScan(scanCallback) } catch (_: Exception) {}
                status.text = "Wyszukiwanie zakończone. Wybierz zegarek z listy."
            }, 12000)
        } catch (e: SecurityException) {
            status.text = "Brak uprawnień do skanowania Bluetooth."
        }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val key = device.address ?: return
            if (found.containsKey(key)) return
            found[key] = device
            runOnUiThread {
                val label = try {
                    (device.name ?: "Urządzenie bez nazwy") + "  •  " + key
                } catch (_: SecurityException) { "Urządzenie BLE" }
                val button = Button(this@MainActivity).apply {
                    text = label
                    setOnClickListener { connect(device) }
                }
                devicesBox.addView(button)
            }
        }

        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { status.text = "Błąd skanowania Bluetooth: $errorCode" }
        }
    }

    private fun connect(device: BluetoothDevice) {
        try {
            status.text = "Łączenie z urządzeniem…"
            gatt?.close()
            gatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: SecurityException) {
            status.text = "Brak uprawnień do połączenia."
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            runOnUiThread {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    status.text = "Połączono. Odczytuję usługi Bluetooth…"
                    try { g.discoverServices() } catch (_: SecurityException) {}
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    status.text = "Połączenie zakończone."
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            runOnUiThread {
                devicesBox.removeAllViews()
                val heading = TextView(this@MainActivity).apply {
                    text = "Usługi udostępnione przez urządzenie:"
                    textSize = 17f
                }
                devicesBox.addView(heading)
                g.services.forEach { service ->
                    val row = TextView(this@MainActivity).apply {
                        text = service.uuid.toString()
                        textSize = 13f
                        setPadding(0, 8, 0, 8)
                    }
                    devicesBox.addView(row)
                }
                status.text = if (statusCode == BluetoothGatt.GATT_SUCCESS)
                    "Połączono — znaleziono ${g.services.size} usług."
                else "Połączono, ale nie udało się odczytać usług."
            }
        }
    }

    override fun onDestroy() {
        try { gatt?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
